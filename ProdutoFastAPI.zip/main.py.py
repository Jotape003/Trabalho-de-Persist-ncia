'''
    Exercício: Criando uma API CRUD de Produtos com FastAPI
    Descrição da Entidade
    A entidade principal será Produto, com os seguintes campos:
    Campo Tipo Descrição
    id int Identificador único do produto
    nome str Nome do produto
    categoria str Categoria do produto
    preco float Preço do produto
    1. Crie um arquivo main.py com a API FastAPI.
    2. A API deve conter os seguintes endpoints:
    Método Endpoint Descrição
    GET /produtos Retorna todos os produtos
    GET /produtos/{id} Retorna o produto com o id informado
    POST /produtos Cadastra um novo produto
    PUT /produtos/{id} Atualiza os dados de um produto existente
    DELETE /produtos/{id} Remove o produto com o id informado
    1. Os dados devem ser armazenados em um DataFrame pandas, e não em banco de dados.
    2. Crie um segundo arquivo, cliente.py, para testar os endpoints usando a biblioteca
    httpx.
'''

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pandas as pd

app = FastAPI()
contador_id = 4
produto_df = pd.DataFrame({
    "id" : [1,2,3],
    "nome": ["Arroz", "Feijão", "Batata"],
    "categoria": ["Carboidrato", "Carboidrato", "Legume"],
    "preco": [30.0, 20.0, 8.0]
})

class Produto(BaseModel):
    nome: str
    categoria: str
    preco: float


# Serviço de criação de um produto
@app.post("/produto")
def criar_produto(produto: Produto):
    global contador_id, produto_df

    novo_produto = {
        'id': contador_id,
        'nome': produto.nome,
        'categoria': produto.categoria,
        'preco': produto.preco
    }

    produto_df = pd.concat([produto_df, pd.DataFrame([novo_produto])], ignore_index = True)

    contador_id += 1

    return {
        'mensagem': 'Produto cadastrado com sucesso',
        'produto': novo_produto
    }

# Serviço de listagem de TODOS os produtos
@app.get("/produto")
def listar_alunos():
    return produto_df.to_dict(orient = "records")

# Serviço de listagem de um único produto
@app.get("/produto/{id}")
def obter_produto(id: int):
    global produto_df
    filtro = produto_df["id"] == id
    produto = produto_df[filtro]

    if produto.empty:
        raise HTTPException(status_code=404, detail = f"Produto id: {id}, não encontrado")
    return produto.to_dict(orient="records")[0] 

# Serviço de atualizar um produto específico
@app.put("/produto/{id}")
def atualizar_produto(id: int, produto: Produto):
    global produto_df
    produto_antigo_idx = produto_df.index[produto_df["id"] == id]

    if produto_antigo_idx.empty:
        raise HTTPException(status_code=404, detail=f"Produto id:{id}, não encontrado")
    
    produto_df.loc[produto_antigo_idx, ["nome", "categoria", "preco"]] = [produto.nome, produto.categoria, produto.preco]

    return {
        "mensagem": f"Produto {id} atualizado com sucesso!",
        "produto": produto_df.loc[produto_antigo_idx].to_dict(orient="records")[0]
    }

@app.delete("/produto/{id}")
def apagar_produto(id: int):
    global produto_df
    produto_apagar_idx = produto_df.index[produto_df["id"] == id]

    if produto_apagar_idx.empty:
        raise HTTPException(status_code=404, detail=f"Produto id:{id}, não encontrado")
    
    produto_df = produto_df.drop(produto_apagar_idx).reset_index(drop=True)
    return {"mensagem": f"Produto com {id} apagado com sucesso!"}



    